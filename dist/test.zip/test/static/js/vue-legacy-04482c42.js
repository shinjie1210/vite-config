System.register([],(function(){"use strict";return{execute:function(){}}}));
