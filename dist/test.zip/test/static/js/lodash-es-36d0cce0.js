function u(e){for(var n=-1,r=e==null?0:e.length,l={};++n<r;){var t=e[n];l[t[0]]=t[1]}return l}export{u as f};
