System.register([],(function(t){"use strict";return{execute:function(){t("f",(function(t){for(var e=-1,n=null==t?0:t.length,r={};++e<n;){var u=t[e];r[u[0]]=u[1]}return r}))}}}));
